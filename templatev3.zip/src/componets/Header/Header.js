// HeaderComponent.js
import React from 'react';
import '../Header/header.css';

const Header = () => {
  return (
    <div>
      <header className="header header-primary">
        KUMARAGURU COLLEGE OF TECHNOLOGY -COIMBATORE 
      </header>
     
    </div>
  );
};

export default Header;
